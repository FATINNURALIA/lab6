package lab6.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import lab6.com.Marathon;

public class MarathonDAO {
    private Connection connection;

    public MarathonDAO() throws ClassNotFoundException {
        connection = Database.getConnection();
    }

    public int addDetails(Marathon marathon) {
        int result = 0;
        try {
            String insertMarathon = "INSERT INTO marathon VALUES (?, ?, ?)";
            PreparedStatement preparedStatement = connection.prepareStatement(insertMarathon);

            // Parameters
            preparedStatement.setString(1, marathon.getIcNo());
            preparedStatement.setString(2, marathon.getName());
            preparedStatement.setString(3, marathon.getCategory());

            result = preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return result;
    }
}
